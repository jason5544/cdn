./cdn ../../case_example/case1.txt result.txt
