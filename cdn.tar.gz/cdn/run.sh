rm debug.txt
./cdn ../../case_example/case0.txt result.txt >> debug.txt
